#Hw2 Project 1
#File Name:main.py
#Programmer: Janelle Hizon
#Date: June 20, 2020

#problem: question asks to put an introduction line into code in order to tell user what code will accomplish for them.

#plan:
#1. copy and paste convert.py file 
#2. modify and add print line at beginning to introduce code and its purpose. 

# name method
def main () :
  
  #print introduction statement
  print("Hi! \nThis program will convert a Celsius temperature to Farenheit temperature for you.")

  #prompt for user input (original code from 2.2, unmodified)
  celsius = eval (input ("What is the Celsius temperature? ") )

  #compute conversion and store value in farenheit variable
  fahrenheit = 9/5 * celsius + 32

  #print results in formatted line
  print ("The temperature is", fahrenheit, "degrees Fahrenheit.")

#call  method
main () 